The datasets are located in the data folder.

This code requires Python 3.5 or newer and the sklearn python package (pip3 install scikit-learn).

Run it with: python3 main.py <path to csv>

Graphs will be put in the respective folders in the graphs directory and will be automatically named.
